<?php

echo "<h1>Payment success</h1><br>";
if(isset($_GET['paymentId'])){
	echo "Payment Id:". $_GET['paymentId']."<br>";
}
if(isset($_GET['token'])){
	echo "token:". $_GET['token']."<br>";
}
if(isset($_GET['PayerID'])){
	echo "PayerID:". $_GET['PayerID']."<br>";
}
