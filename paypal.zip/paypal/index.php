<?php
error_reporting(E_ALL);
ini_set('display_errors',1);
$method = 'card';
$name = 'Pragnesh';
$firstname = 'Pragnesh';
$lastname = 'Patel';
$cardtype = 'visa';
$cardnumber = '4148529247832259';
$cvv = '012';
$expirymonth = '11';
$expiryyear = '2020';
$amountToCut  = 100.00;
require_once 'paypal_sdk.php';
$cdo = new CdoPay();

if($method == "card"){
 $result = $cdo->payment($firstname, $lastname, $cardnumber, $cardtype, $expirymonth, $expiryyear, $cvv,$amountToCut);
 echo "<pre>";print_r($result);exit;
}else{
 $url = $cdo->payment_using_web($amountToCut);
 header("Location:" . $url);
}
